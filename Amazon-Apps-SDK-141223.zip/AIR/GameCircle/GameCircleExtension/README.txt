Documentation for the Amazon GameCircle Adobe AIR Extension can be found at:
https://developer.amazon.com/sdk/gamecircle.html