function deviceOrientationEventHandler(data) {
    // 0 = portrait which is what the rest of the dimensions are based on
    // Force to be positive; some devices report negative angles in some orientations
    var orientation = (window.orientation + 360) % 360;
    var tiltLeftRight;
    var tiltFrontBack;
    var direction;
    
    // This normalization that is shown below only works well as long as the
    // device is generally pointed upward. The data is still technically correct
    // but would behave differently between portrait and landscape. Full
    // polar normalization would have to be done to get around this if it
    // was an important feature for you.
    if (orientation === 0) {
        tiltLeftRight = data.gamma;
        tiltFrontBack = data.beta;
    }
    else if (orientation === 90) {
        tiltLeftRight = data.beta;
        tiltFrontBack = -data.gamma;        
    }
    else if (orientation === 180) {
        tiltLeftRight = -data.gamma;
        tiltFrontBack = -data.beta;                
    }
    else if (orientation === 270) {
        tiltLeftRight = -data.beta;
        tiltFrontBack = data.gamma;                
    }
    
    direction = data.alpha;
    
    $("#tilt-lr").text(Math.round(tiltLeftRight));
    $("#tilt-fb").text(Math.round(tiltFrontBack));
    $("#direction").text(Math.round(direction));
    $("#orientation").text(window.orientation);
    
    // As noted above the normalization is not stable when the screen
    // is pointed downward. Since this is a bubble-level app, just ensure
    // the bubble doesn't leave its bounding area.
    $("#bubble").css(
        {
            top: boundToRange(tiltFrontBack, -90, 90) * 2 + 190 + "px",
            left: boundToRange(tiltLeftRight, -90, 90) * 2 + 190 + "px"
        });
}

function boundToRange(number, min, max) {
    if (number < min) {
        return min;
    }
    if (number > max) {
        return max;    
    }
    return number;
}

function init() {

    if ("ondeviceorientation" in window) {
        // In this example we're specifically using device orientation
        // and not simply orientationchange which handles device
        // rotation (e.g. portrait versus landscape)        
        window.addEventListener("deviceorientation", deviceOrientationEventHandler);
        $("#supported").show();
        $("#not-supported").hide();
    }
    else {
        $("#supported").hide();
        $("#not-supported").show();
    }
}

$(function() { init(); });
