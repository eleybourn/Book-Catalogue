function getLocation() {

    var options = {
      enableHighAccuracy: true, // Hint to try to use true GPS instead of other location proxies like WiFi or cell towers
      timeout: 5000,            // Maximum number of milliseconds to wait before timing out
      maximumAge: 0             // Maximum of milliseconds since last position fix
    };

    // First check to verify that the API exists
    if (navigator.geolocation) {
        // getCurrentPosition takes two callbacks for success and error and the options.
        navigator.geolocation.getCurrentPosition(showPosition, showPositionError, options);
    } else {
        $("#location").text("Geolocation is not supported in this browser or context");
    }
}

// Here's where you put the guts of the location handling for your application
function showPosition(position) {
    $("#location").html("Latitude: " + position.coords.latitude + "<br/>Longitude: " + position.coords.longitude + "<br/>Accuracy: " + position.coords.accuracy + " meters");
    $("#osm").html('<a href="http://www.openstreetmap.org/?lat=' + position.coords.latitude + '&lon=' + position.coords.longitude + '&zoom=17&layers=M">Open Street Maps view</a>');
}

// Called in case of error
function showPositionError(err) {
    $("#location").text("Error getting location: " + err.message + " (" + err.code + ")");
}
