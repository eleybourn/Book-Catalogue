Amazon Web App API
 
The Amazon Web App API provides APIs, tools, and resources to leverage
the features and services offered by Amazon. As a developer, you can benefit
from best practices, implementation specifics, and reference material
that allow you to devote more time to creating great apps and less time
worrying about implementation details.
 
Features
 
Amazon Web App API includes:
 
In-App Purchasing API - The In-App Purchasing API makes it easy for you
to offer digital content and subscriptions for purchase within your apps,
such as in-game currency, expansion packs, upgrades, and magazine issues
and more. Within minutes you can be up and running, ready to give
millions of Amazon customers the ability to purchase engaging digital
content using their Amazon 1-Click settings.

 
See http://developer.amazon.com for more information.
